.onLoad <- function(libname, pkgname) {
  library(stringr, quietly = TRUE)
}
