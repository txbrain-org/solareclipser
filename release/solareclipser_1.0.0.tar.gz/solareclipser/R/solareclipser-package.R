#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @useDynLib solareclipser, .registration = TRUE
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
