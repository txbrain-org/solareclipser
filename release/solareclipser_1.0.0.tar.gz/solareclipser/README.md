
<!-- README.md is generated from README.Rmd. Please edit that file -->

# solareclipser

<!-- badges: start -->

<!-- badges: end -->

`solareclipser` is an R package for
[SOLAR-Eclipse](https://www.nitrc.org/projects/se_linux/).

## Installation

base R installation:

1.  Download the tarball from the [releases
    page](https://github.com/txbrain-org/solareclipser/tree/main/release)

2.  Install the package with the following command (replace the path
    with the actual path to the downloaded file):
    
    ``` r
    install.packages("path/to/package.tar.gz", repos = NULL, type = "source")
    ```

## Example
