
<!-- README.md is generated from README.Rmd. Please edit that file -->

# solareclipser

<!-- badges: start -->

<!-- badges: end -->

`solareclipser` is an R package for
[SOLAR-Eclipse](https://www.nitrc.org/projects/se_linux/).

## Installation

### solareclipser

``` r
install.packages("devtools")
devtools::install_github("txbrain-org/solareclipser")
```

## Example
